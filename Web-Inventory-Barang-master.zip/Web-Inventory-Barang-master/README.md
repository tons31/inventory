# Web-Inventory-Barang
Inventory Barang Berbasis Web
___________________________________________________________________________________________________________________________________________________________________

<strong>Tentang Website Inventory</strong>


Website inventory adalah aplikasi berbasis Web untuk mengatur dan mencatat keluar masuk barang di masing-masing gudang dalam satu perusahaan, yang meliputi pencatatan barang masuk dari Supplier dan pencatatan barang keluar.

<strong>Fitur website</strong>
  1. Fitur Login
    <ul type="square">
    <li>Memakai pengamanan MD5 untuk password</li>
    <li>Admin dan Petugas mempunyai tempat loginnya masing - masing</li>
    </ul>
  2. Fitur Admin
  
  <ul type="square">
    <li>Admin bisa melihat statistik data di dashboard nya</li>
    <li>Admin bisa melihat, menambahkan, menghapus dan mengubah data admin</li>
    <li>Admin bisa melihat, menambahkan, menghapus dan mengubah data petugas</li>
    <li>Admin bisa melihat, menambahkan, menghapus dan mengubah data supplier</li>
    <li>Admin bisa melihat, menambahkan, dan menghapus data rak</li>
    <li>Admin bisa melihat, menambahkan, menghapus dan mengubah data barang</li>
    <li>Admin bisa menyetujui ajuan pengeluaran barang yang di ajukan oleh petugas</li>
  </ul>
 
  3. Fitur Petugas
   <ul type="square">
    <li>Petugas bisa melihat statistik data di dashboard nya</li>
    <li>Petugas bisa menambahkan stok barang</li>
    <li>Petugas bisa mengajukan barang kepada admin</li>
    
  </ul>
  
  ________________________________________________________________________________________________________________________________________________________________
  <strong>Login default : </strong>
  1. Login Admin :
  <ul type="square">
    <li>username = admin </li>
    <li>password = admin</li>
   
  </ul>
 
  2. Login Petugas
   <ul type="square">
    <li>username = petugas</li>
    <li>password = petugas</li>

    
  </ul>
  
  
-> Catatan(PENTING) :
    <i>Sebelum mengimport database, pastikan anda membuat database sesuai dengan nama database yang ada di dalam folder DATABASE, yaitu 'inventory'</i>